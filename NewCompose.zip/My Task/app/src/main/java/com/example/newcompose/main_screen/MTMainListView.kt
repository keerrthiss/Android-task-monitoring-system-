package com.example.newcompose.main_screen

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.newcompose.isValidList
import com.example.newcompose.ui.theme.NewComposeTheme
import com.google.accompanist.swiperefresh.SwipeRefresh
import com.google.accompanist.swiperefresh.SwipeRefreshIndicator
import com.google.accompanist.swiperefresh.rememberSwipeRefreshState

@Composable
fun MTMainListView(
    modifier: Modifier = Modifier,
    listState: LazyListState,
    onRefreshPage: () -> Unit,
    onFetchNextPage: () -> Unit,
    list: List<MTListPair>?,
    showBottomLoading: Boolean = false,
    swipeEnabled: Boolean = true,
    onItemClick: (String) -> Unit,
) {
    val atLastIndex by remember {
        derivedStateOf {
            listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index == listState.layoutInfo.totalItemsCount - 1
        }
    }

    LaunchedEffect(atLastIndex) {
        if (atLastIndex) onFetchNextPage()
    }

    val refreshing by remember { mutableStateOf(false) }
    Column(modifier = modifier) {
        SwipeRefresh(
            state = rememberSwipeRefreshState(isRefreshing = refreshing),
            onRefresh = onRefreshPage,
            indicator = { state, trigger ->
                SwipeRefreshIndicator(
                    state = state,
                    refreshTriggerDistance = trigger,
                    contentColor = MaterialTheme.colors.primary
                )
            },
            swipeEnabled = swipeEnabled
        ) {
            if (list?.isValidList() == true) {
                LazyColumn(
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    list.forEachIndexed { index, miTiListData ->
                        item(key = index) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier,
                            ) {
                                Text(
                                    text = miTiListData.key.toString(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colors.background)
                                        .padding(start = 20.dp, end = 20.dp, top = 10.dp)
                                )
                            }
                        }
                        items(miTiListData.value) { listContent ->
                            Row {
                                MTMainEntryCard(
                                    modifier = Modifier.padding(
                                        horizontal = 20.dp,
                                        vertical = 5.dp
                                    ),
                                    taskName = listContent.task.toString(),
                                    taskDuration = listContent.duration.toString(),
                                    taskDBId = listContent.taskDBId.toString(),
                                    onItemClick = onItemClick,
                                )
                            }
                        }
                    }
                }
            } else {
                MTEmptyScreen()
            }
        }
    }
}

@Composable
fun MTEmptyScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "No entries to display")
    }
}

@Preview
@Preview(uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
fun MTMainListViewPreview() {
    NewComposeTheme {
        MTMainListView(
            listState = rememberLazyListState(),
            onRefreshPage = {},
            onFetchNextPage = {},
            list = listOf(),
            showBottomLoading = false,
            onItemClick = {}
        )
    }
}