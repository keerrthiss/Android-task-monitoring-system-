package com.example.newcompose.timer_screen

import android.annotation.SuppressLint
import androidx.compose.animation.*
import androidx.compose.ui.unit.dp
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.navigation.NavHostController
import com.example.newcompose.MICenterAlignedTopAppBar
import com.example.newcompose.R
import com.example.newcompose.ui.theme.darkBlue
import com.example.newcompose.ui.theme.darkRed
import com.example.newcompose.ui.theme.lightBlue
import com.example.newcompose.ui.theme.lightRed

@Composable
fun MTTimerScreen(
    viewModel: MTTimerScreenViewModel = hiltViewModel(),
    navController: NavHostController,
    taskDBId: String,
) {
    val lifecycleOwner: LifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(Unit) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (taskDBId.isNotBlank()) viewModel.getTask(taskDBId = taskDBId)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }
    MTStopwatch(
        isPlaying = viewModel.isPlaying,
        seconds = viewModel.seconds,
        minutes = viewModel.minutes,
        hours = viewModel.hours,
        onStart = { viewModel.start() },
        onPause = { viewModel.pause() },
        onStop = { viewModel.stop() },
        onSaveButtonClick = { task, duration ->
            if (taskDBId.isBlank()) viewModel.addTask(task, duration)
            else viewModel.updateTask(task, duration)
            navController.popBackStack()
        },
        taskName = viewModel.uiState.taskName ?: "",
        onDeleteButtonClick = {
            viewModel.deleteTask()
            navController.popBackStack()
        },
        onDeleteRequired = taskDBId.isNotBlank()
    )
}

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@OptIn(ExperimentalAnimationApi::class)
@Composable
private fun MTStopwatch(
    isPlaying: Boolean,
    seconds: String,
    minutes: String,
    hours: String,
    onStart: () -> Unit = {},
    onPause: () -> Unit = {},
    onStop: () -> Unit = {},
    onSaveButtonClick: (String, String) -> Unit,
    taskName: String,
    onDeleteButtonClick: () -> Unit,
    onDeleteRequired: Boolean,
) {
    val task = remember { mutableStateOf(TextFieldValue()) }
    task.value = TextFieldValue(text = taskName)
    val taskErrorState = remember { mutableStateOf(false) }
    Scaffold(
        topBar = { MICenterAlignedTopAppBar(title = "MyTimer") },
    ) {
        OutlinedTextField(
            value = task.value,
            onValueChange = { _task ->
                if (taskErrorState.value) {
                    taskErrorState.value = false
                }
                task.value = _task
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            label = { Text(text = "Enter the task") },
            isError = taskErrorState.value
        )
        Spacer(modifier = Modifier.height(30.dp))
        Column(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row {
                val numberTransitionSpec: AnimatedContentScope<String>.() -> ContentTransform = {
                    slideInVertically(
                        initialOffsetY = { it }
                    ) + fadeIn() with slideOutVertically(
                        targetOffsetY = { -it }
                    ) + fadeOut() using SizeTransform(
                        false
                    )
                }
                CompositionLocalProvider(LocalTextStyle provides MaterialTheme.typography.h3) {
                    AnimatedContent(targetState = hours, transitionSpec = numberTransitionSpec) {
                        Text(text = it)
                    }
                    Text(text = ":")
                    AnimatedContent(targetState = minutes, transitionSpec = numberTransitionSpec) {
                        Text(text = it)
                    }
                    Text(text = ":")
                    AnimatedContent(targetState = seconds, transitionSpec = numberTransitionSpec) {
                        Text(text = it)
                    }
                }
            }
            Spacer(modifier = Modifier.height(50.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.background(Color.LightGray, RoundedCornerShape(50))
            ) {
                AnimatedContent(targetState = isPlaying) {
                    if (it)
                        IconButton(onClick = onPause) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_baseline_pause_24),
                                contentDescription = ""
                            )
                        }
                    else
                        IconButton(onClick = onStart) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_baseline_play_arrow_24),
                                contentDescription = ""
                            )
                        }
                }
                IconButton(onClick = onStop) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_baseline_stop_24),
                        contentDescription = ""
                    )
                }
            }
            Spacer(modifier = Modifier.height(32.dp))
            MTGradientButton(
                text = "Save",
                textColor = Color.White,
                gradient = Brush.horizontalGradient(
                    colors = listOf(lightBlue, darkBlue)
                ),
                onClick = {
                    if (task.value.text.isNotBlank()) {
                        onSaveButtonClick(task.value.text, "$hours:$minutes:$seconds")
                    } else {
                        taskErrorState.value = true
                    }
                },
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            if (onDeleteRequired) {
                MTGradientButton(
                    text = "Delete",
                    textColor = Color.White,
                    gradient = Brush.horizontalGradient(
                        colors = listOf(lightRed, darkRed)
                    ),
                    onClick = onDeleteButtonClick,
                    modifier = Modifier.padding(horizontal = 20.dp)
                )
            }
        }
    }
}