package com.example.newcompose.common

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MTApplication : Application()  {
    private var database: MTDatabase? = null
    companion object {
        private val TAG = MTApplication::class.java.simpleName
        private lateinit var instance: MTApplication

        /**
         * To get the application instance
         *
         * @return The application instance
         */
        fun getInstance(): MTApplication = instance
    }

    override fun onCreate() {
        super.onCreate()
        initInstance()
    }

    private fun initInstance() {
        instance = this
        database = MTDatabase.getInstance(this)
    }

    /**
     * To get the instance of database
     *
     * @return The database instance
     */
    fun getDatabase(): MTDatabase? = database
}