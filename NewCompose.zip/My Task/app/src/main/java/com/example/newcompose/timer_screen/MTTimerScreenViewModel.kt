package com.example.newcompose.timer_screen

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.newcompose.common.MTDatabase
import com.example.newcompose.main_screen.MTTask
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import kotlin.concurrent.fixedRateTimer
import kotlin.time.Duration.Companion.seconds
import kotlin.time.Duration
import kotlin.time.Duration.Companion.hours
import kotlin.time.Duration.Companion.minutes
import kotlin.time.ExperimentalTime


@HiltViewModel
class MTTimerScreenViewModel @Inject constructor(
    private val database: MTDatabase,
) : ViewModel() {
    var uiState by mutableStateOf(MTTimerScreenUIState())
        private set

    private var time: Duration = Duration.ZERO
    private lateinit var timer: Timer

    var seconds by mutableStateOf("00")
    var minutes by mutableStateOf("00")
    var hours by mutableStateOf("00")
    var isPlaying by mutableStateOf(false)
    var id: Int = 0

    fun start() {
        timer = fixedRateTimer(initialDelay = 1000L, period = 1000L) {
            time = time.plus(1.seconds)
            updateTimeStates()
        }
        isPlaying = true
    }

    private fun updateTimeStates() {
        time.toComponents { hours, minutes, seconds, _ ->
            this@MTTimerScreenViewModel.seconds = seconds.pad()
            this@MTTimerScreenViewModel.minutes = minutes.pad()
            this@MTTimerScreenViewModel.hours = hours.toString().padStart(2, '0')
        }
    }

    private fun Int.pad(): String {
        return this.toString().padStart(2, '0')
    }

    fun pause() {
        try {
            timer.cancel()
            isPlaying = false
        } catch (e: Exception) {
            Log.e("MTTimerScreenViewModel", e.toString())
        }
    }

    fun stop() {
        pause()
        time = Duration.ZERO
        updateTimeStates()
    }

    fun addTask(
        task: String,
        duration: String,
    ) {
        viewModelScope.launch {
            database.getTaskDao()
                .insertTask(
                    MTTask(
                        task = task,
                        date = getCurrentDate(),
                        time = getCurrentTime(),
                        duration = duration,
                        taskDBId = "$task${getCurrentDate()}${getCurrentTime()}"
                    )
                )
        }
    }

    fun updateTask(
        task: String,
        duration: String,
    ) {
        viewModelScope.launch {
            database.getTaskDao().updateTask(
                task = task,
                date = getCurrentDate(),
                time = getCurrentTime(),
                duration = duration,
                taskDBId = "$task${getCurrentDate()}${getCurrentTime()}",
                id = id
            )
        }
    }

    fun getTask(taskDBId: String) {
        viewModelScope.launch {
            val task = database.getTaskDao().getTask(taskDBId)
            id = task?.id ?: 0
            uiState = uiState.copy(taskName = task?.task)
            getDurationFormat(task?.duration)
        }
    }

    private fun getCurrentDate(): String {
        val currentDateFormat =
            SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
        return currentDateFormat.format(Date())
    }

    private fun getCurrentTime(): String {
        val currentDateFormat =
            SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return currentDateFormat.format(Date())
    }

    private fun getDurationFormat(duration: String?) {
        try {
            val splitDuration = duration?.split(":")
            time = time.plus((splitDuration?.get(2)?.toInt() ?: 1).seconds)
            time = time.plus((splitDuration?.get(1)?.toInt() ?: 1).minutes)
            time = time.plus((splitDuration?.get(0)?.toInt() ?: 1).hours)
            time.toComponents { hours, minutes, seconds, _ ->
                this@MTTimerScreenViewModel.seconds = seconds.pad()
                this@MTTimerScreenViewModel.minutes = minutes.pad()
                this@MTTimerScreenViewModel.hours = hours.toString().padStart(2, '0')
            }
        } catch (e: Exception) {
            Log.e("MTTimerScreenViewModel", "getDurationFormat: Exception: " + e.message, e)
                .toString()
        }
    }

    fun deleteTask() {
        viewModelScope.launch {
            database.getTaskDao().deleteTask(id)
        }
    }
}

data class MTTimerScreenUIState(
    val taskName: String? = null,
)