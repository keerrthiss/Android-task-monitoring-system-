package com.example.newcompose.main_screen

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.newcompose.common.MTDatabase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@HiltViewModel
class MTMainViewModel @Inject constructor(
    private val database: MTDatabase,
) : ViewModel() {
    var uiState by mutableStateOf(MTMainUIState())
        private set

    fun getTaskList() {
        val groupedTask: MutableList<MTListPair> = mutableListOf()
        viewModelScope.launch {
            database.getTaskDao().getTasks().collect { task ->
                val grouped = task.groupBy { it.date }
                grouped.forEach {
                    groupedTask.add(
                        MTListPair(
                            it.key,
                            it.value,
                        )
                    )
                }
                uiState = uiState.copy(todayTaskList = groupedTask)
            }
        }
    }
}

data class MTMainUIState(
    val todayTaskList: List<MTListPair>? = null,
)

data class MTListPair(
    val key: String? = null,
    val value: List<MTTask>,
)