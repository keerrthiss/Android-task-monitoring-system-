package com.example.newcompose.main_screen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.newcompose.timer_screen.MTTimerScreen
import com.example.newcompose.R
import com.example.newcompose.ui.theme.NewComposeTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NewComposeTheme {
                Navigation()
            }
        }
    }
}

@Composable
fun Navigation() {
    var taskDBId: String by remember { mutableStateOf("") }
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = "LIST_SCREEN",
        builder = {
            composable(
                "LIST_SCREEN",
                content = {
                    MTMainScreen(
                        navController = navController,
                        onTaskDBIdChange = { taskDBId = it })
                }
            )
            composable(
                "TIMER_SCREEN",
                content = {
                    MTTimerScreen(
                        navController = navController,
                        taskDBId = taskDBId
                    )
                }
            )
        }
    )
}

@Composable
fun SetSplashScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.ic_icons8),
            contentDescription = "Splash screen icon"
        )
    }
}