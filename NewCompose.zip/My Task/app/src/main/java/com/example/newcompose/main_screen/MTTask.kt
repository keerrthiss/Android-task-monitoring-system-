package com.example.newcompose.main_screen

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

@Entity(tableName = "MTTask")
data class MTTask(
    @SerializedName("taskDBId")
    @Expose
    val taskDBId: String? = null,

    @SerializedName("task")
    @Expose
    val task: String? = null,

    @SerializedName("date")
    @Expose
    val date: String? = null,

    @SerializedName("time")
    @Expose
    val time: String? = null,

    @SerializedName("duration")
    @Expose
    val duration: String? = null,

    @PrimaryKey(autoGenerate = true)
    @SerializedName("id")
    @Expose
    val id: Int = 0
)