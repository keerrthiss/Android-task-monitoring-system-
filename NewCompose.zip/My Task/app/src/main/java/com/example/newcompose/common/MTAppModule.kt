package com.example.newcompose.common

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import javax.inject.Qualifier
import javax.inject.Singleton

@Retention(AnnotationRetention.BINARY)
@Qualifier
annotation class MTDefaultDispatcher

@Retention(AnnotationRetention.BINARY)
@Qualifier
annotation class MTIODispatcher

@Module
@InstallIn(SingletonComponent::class)
object MIAppModule {

    @Provides
    @Singleton
    fun provideApplication(): MTApplication = MTApplication.getInstance()

    @Provides
    @Singleton
    fun provideDatabase(): MTDatabase = MTDatabase.getInstance(provideApplication())

    @MTIODispatcher
    @Provides
    fun provideIODispatcher(): CoroutineDispatcher = Dispatchers.IO

    @MTDefaultDispatcher
    @Provides
    fun providesDefaultDispatcher(): CoroutineDispatcher = Dispatchers.Default
}