package com.example.newcompose.ui.theme

import androidx.compose.ui.graphics.Color

val darkBlue = Color(0xFF08528D)
val lightBlue = Color(0xFF2196F3)
val lightRed = Color(0xFFF00620)
val darkRed = Color(0xFFA20819)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)