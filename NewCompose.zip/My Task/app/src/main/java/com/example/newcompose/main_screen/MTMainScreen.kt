package com.example.newcompose.main_screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.material.*
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.navigation.NavHostController
import com.example.newcompose.MICenterAlignedTopAppBar
import com.example.newcompose.R

@Composable
fun MTMainScreen(
    viewModel: MTMainViewModel = hiltViewModel(),
    navController: NavHostController,
    onTaskDBIdChange: (String) -> Unit,
) {
    val lifecycleOwner: LifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(Unit) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.getTaskList()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }
    val uiState = viewModel.uiState
    MTMainScreen(
        todayTaskList = uiState.todayTaskList,
        onFloatingIconClick = {
            onTaskDBIdChange("")
            navController.navigate("TIMER_SCREEN") {
                popUpTo(navController.graph.startDestinationId)
                launchSingleTop = true
            }
        },
        onItemClick = {
            onTaskDBIdChange(it)
            navController.navigate("TIMER_SCREEN") {
                popUpTo(navController.graph.startDestinationId)
                launchSingleTop = true
            }
        }
    )
}

@Composable
fun MTMainScreen(
    listState: LazyListState = rememberLazyListState(),
    todayTaskList: List<MTListPair>?,
    onFloatingIconClick: () -> Unit,
    onItemClick: (String) -> Unit,
) {
    Scaffold(
        topBar = { MICenterAlignedTopAppBar(title = "MyTask") },
        floatingActionButton = {
            FloatingActionButton(
                modifier = Modifier,
                onClick = onFloatingIconClick,
                backgroundColor = MaterialTheme.colors.primary,
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_baseline_access_time_filled_24),
                    contentDescription = "Add task"
                )
            }
        },
        isFloatingActionButtonDocked = true,
    ) {
        Column(modifier = Modifier.padding(it)) {
            MTMainListView(
                listState = listState,
                list = todayTaskList,
                onRefreshPage = {},
                onFetchNextPage = {},
                onItemClick = onItemClick,
            )
        }
    }
}