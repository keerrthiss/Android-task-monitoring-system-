package com.example.newcompose.common

import android.content.Context
import androidx.room.*
import com.example.newcompose.main_screen.MTTask
import kotlinx.coroutines.flow.Flow

@Database(
    entities = [MTTask::class],
    version = 1,
    exportSchema = false
)
abstract class MTDatabase : RoomDatabase() {
    companion object {
        private const val DATABASE_NAME = "MyTask.db"

        // Singleton prevents multiple instances of database opening at the
        // same time.
        @Volatile
        private var INSTANCE: MTDatabase? = null

        /**
         * To get the database instance
         * @param context represent the app context
         * @return database instance
         */
        fun getInstance(context: Context): MTDatabase {
            // if the INSTANCE is not null, then return it,
            // if it is, then create the database
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MTDatabase::class.java,
                    DATABASE_NAME
                ).build()
                INSTANCE = instance
                // return instance
                instance
            }
        }
    }

    abstract fun getTaskDao(): MTTaskDao
}

@Dao
interface MTTaskDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: MTTask)

    @Query("SELECT * FROM MTTask ORDER BY date ASC")
    fun getTasks(): Flow<List<MTTask>>

    @Query("UPDATE MTTask SET task = :task, date = :date, time = :time, duration = :duration, taskDBId = :taskDBId WHERE id = :id")
    suspend fun updateTask(
        task: String,
        date: String,
        time: String,
        duration: String,
        taskDBId: String,
        id: Int,
    )

    @Query("SELECT * FROM MTTask WHERE taskDBId = :taskDBId")
    suspend fun getTask(taskDBId: String): MTTask?

    @Query("DELETE FROM MTTask WHERE id = :id")
    suspend fun deleteTask(id: Int)
}