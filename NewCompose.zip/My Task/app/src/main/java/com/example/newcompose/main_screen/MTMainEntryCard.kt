package com.example.newcompose.main_screen

import android.content.res.Configuration
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.newcompose.R

@Composable
fun MTMainEntryCard(
    modifier: Modifier = Modifier,
    taskName: String,
    taskDuration: String,
    onItemClick: (String) -> Unit,
    taskDBId: String,
) {
    Card(
        modifier = modifier
            .height(56.dp)
            .fillMaxWidth()
            .shadow(elevation = 3.dp, shape = RoundedCornerShape(10.dp))
            .clickable { onItemClick(taskDBId) },
        shape = MaterialTheme.shapes.large
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp),
        ) {
            Row(
                modifier = Modifier.align(Alignment.CenterStart),
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_dependency_icon),
                    contentDescription = "Todo Icon",
                    tint = MaterialTheme.colors.onBackground,
                    modifier = Modifier
                        .height(20.dp)
                        .width(20.dp)
                )
                Text(
                    text = taskName,
                    modifier = Modifier.padding(start = 20.dp),
                    color = MaterialTheme.colors.onBackground,
                    fontSize = 14.sp,
                    textAlign = TextAlign.End,
                )
            }
            Text(
                text = taskDuration,
                modifier = Modifier.align(Alignment.CenterEnd),
                color = MaterialTheme.colors.primary,
                fontSize = 14.sp,
                textAlign = TextAlign.End,
            )
        }
    }
}

@Preview
@Preview(uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
fun MainEntryCardPreview() {
    MTMainEntryCard(
        taskName = "Scrum Meeting",
        taskDuration = "3h 21m 33s",
        onItemClick = { },
        taskDBId = "hewuhwieh"
    )
}